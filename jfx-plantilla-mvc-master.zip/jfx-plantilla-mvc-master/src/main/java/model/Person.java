
package model;

public class Person {
    public String getSalutation(){
       return "Hola, soy una persona de ejemplo";
    }
}
