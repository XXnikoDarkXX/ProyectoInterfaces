# jfx-plantilla-mvc

Esqueleto para desarrollo de aplicaciones Java FX con patrón MVC y vistas con FXML

## Instrucciones
1. Descargar el código como un zip del repositorio
2. Modificar el `artifactId` del `pom.xml` para renombrar el proyecto
3. Asegurarse de que compila y se ejecuta correctamente